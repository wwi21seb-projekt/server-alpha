## Planned REST APIs for User Stories 6-10

The user stories were published with Postman and are available at the following link: https://documenter.getpostman.com/view/14045876/2s9YeK2p7M
