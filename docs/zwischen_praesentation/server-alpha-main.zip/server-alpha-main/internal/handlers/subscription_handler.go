package handlers

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"server-alpha/internal/managers"
	"server-alpha/internal/schemas"
	"server-alpha/internal/utils"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	log "github.com/sirupsen/logrus"
)

// SubscriptionHdl defines the interface for handling subscription-related HTTP requests.
type SubscriptionHdl interface {
	HandleGetSubscriptions(w http.ResponseWriter, r *http.Request)
	Subscribe(w http.ResponseWriter, r *http.Request)
	Unsubscribe(w http.ResponseWriter, r *http.Request)
}

// SubscriptionHandler provides methods to handle subscription-related HTTP requests.
type SubscriptionHandler struct {
	DatabaseManager managers.DatabaseMgr
	JwtManager      managers.JWTMgr
}

// NewSubscriptionHandler returns a new SubscriptionHandler with the provided database manager.
func NewSubscriptionHandler(databaseManager *managers.DatabaseMgr) SubscriptionHdl {
	return &SubscriptionHandler{
		DatabaseManager: *databaseManager,
	}
}

// HandleGetSubscriptions handles retrieving subscriptions of a user and sending a paginated response.
// It extracts the username from the URL, fetches subscriptions based on the subscription type, and sends the response.
func (handler *SubscriptionHandler) HandleGetSubscriptions(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithDeadline(r.Context(), time.Now().Add(10*time.Second))
	defer func() {
		if err := ctx.Err(); err != nil {
			log.Debug("Context error: ", err)
		}
		cancel()
		log.Debug("Context canceled")
	}()

	// Get the username from the path variable
	username := chi.URLParam(r, utils.UsernameKey)

	// Get pagination parameters
	offset, limit, err := utils.ParsePaginationParams(r)
	if err != nil {
		utils.WriteAndLogError(ctx, w, schemas.BadRequest, http.StatusBadRequest, err)
		return
	}

	// Get subscription type from query params
	subscriptionType := r.URL.Query().Get(utils.SubscriptionTypeParamKey)

	// Get the followers by default
	userTypes := []string{"subscriber", "subscribee"}

	// If the subscription type is following, fetch the users the user is following
	if subscriptionType == "following" {
		userTypes = []string{"subscribee", "subscriber"}
	}

	findUserQuery := "SELECT user_id FROM alpha_schema.users WHERE username = $1"
	rows, err := handler.DatabaseManager.GetPool().Query(ctx, findUserQuery, username)
	if err != nil {
		utils.WriteAndLogError(ctx, w, schemas.DatabaseError, http.StatusInternalServerError, err)
		return
	}
	if !rows.Next() {
		utils.WriteAndLogError(ctx, w, schemas.UserNotFound, http.StatusNotFound, errors.New("user not found"))
		return
	}

	subscriptionQuery := fmt.Sprintf(`
    SELECT s2.subscription_id, s3.subscription_id, u.username,u.nickname, u.profile_picture_url
	FROM alpha_schema.users AS u
	JOIN alpha_schema.subscriptions AS s1 ON u.user_id = s1.%[1]s_id
	LEFT JOIN alpha_schema.subscriptions AS s2 ON u.user_id = s2.subscribee_id 
    	AND s2.subscriber_id = $1
	LEFT JOIN alpha_schema.subscriptions AS s3 ON u.user_id = s3.subscriber_id 
    	AND s3.subscribee_id = $1
	WHERE s1.%[2]s_id = (SELECT user_id FROM alpha_schema.users WHERE username = $2)
	ORDER BY s1.created_at DESC`, userTypes[0], userTypes[1])

	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM alpha_schema.subscriptions s WHERE s.%[1]s_id = "+
		"(SELECT user_id FROM alpha_schema.users WHERE username = $1)", userTypes[1])

	// Get user id from jwt token
	claims := r.Context().Value(utils.ClaimsKey).(jwt.MapClaims)
	jwtUserId := claims["sub"].(string)

	rows, err = handler.DatabaseManager.GetPool().Query(ctx, subscriptionQuery, jwtUserId, username)
	if err != nil {
		utils.WriteAndLogError(ctx, w, schemas.DatabaseError, http.StatusInternalServerError, err)
		return
	}

	results := make([]schemas.SubscriptionUserDTO, 0)

	for rows.Next() {
		subscription := schemas.SubscriptionUserDTO{}
		followerId, followingId := uuid.UUID{}, uuid.UUID{}

		if err := rows.Scan(&followingId, &followerId, &subscription.Username, &subscription.Nickname, &subscription.ProfilePictureUrl); err != nil {
			utils.WriteAndLogError(ctx, w, schemas.DatabaseError, http.StatusInternalServerError, err)
			return
		}

		if followingId != uuid.Nil {
			followingIdStr := followingId.String()
			subscription.FollowingId = &followingIdStr
		}
		if followerId != uuid.Nil {
			followerIdStr := followerId.String()
			subscription.FollowerId = &followerIdStr
		}

		results = append(results, subscription)
	}

	row := handler.DatabaseManager.GetPool().QueryRow(ctx, countQuery, username)
	var totalSubscriptions int
	if err := row.Scan(&totalSubscriptions); err != nil {
		utils.WriteAndLogError(ctx, w, schemas.DatabaseError, http.StatusInternalServerError, err)
		return
	}

	// Send response
	utils.SendPaginatedResponse(ctx, w, results, offset, limit, totalSubscriptions)
}

// Subscribe handles creating a new subscription between the current user and the specified user in the request.
// It validates the request, checks if the subscription already exists, creates a new subscription if it doesn't exist,
// and sends the subscription details in the response.
func (handler *SubscriptionHandler) Subscribe(w http.ResponseWriter, r *http.Request) {
	// Begin a new transaction
	tx, transactionCtx, cancel := utils.BeginTransaction(w, r, handler.DatabaseManager.GetPool())
	if tx == nil || transactionCtx == nil {
		return
	}
	var err error
	defer utils.RollbackTransaction(w, tx, transactionCtx, cancel, err)

	// Decode the request body into the subscription request struct
	subscriptionRequest := &schemas.SubscriptionRequest{}
	if err := utils.DecodeRequestBody(transactionCtx, w, r, subscriptionRequest); err != nil {
		return
	}

	// Validate the subscription request struct using the validator
	if err := utils.ValidateStruct(transactionCtx, w, subscriptionRequest); err != nil {
		return
	}

	// Get subscribeeId from request body
	queryString := "SELECT user_id FROM alpha_schema.users WHERE username = $1"
	row := tx.QueryRow(transactionCtx, queryString, subscriptionRequest.Following)
	var subscribeeId string
	if err := row.Scan(&subscribeeId); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			utils.WriteAndLogError(transactionCtx, w, schemas.UserNotFound, http.StatusNotFound, err)
			return
		}

		utils.WriteAndLogError(transactionCtx, w, schemas.DatabaseError, http.StatusInternalServerError, err)
		return
	}

	// Get the user ID from the JWT token
	claims := r.Context().Value(utils.ClaimsKey).(jwt.MapClaims)
	jwtUserId := claims["sub"].(string)
	jwtUsername := claims["username"].(string)

	// Check and throw error if the user wants to subscribe to himself
	if jwtUserId == subscribeeId {
		utils.WriteAndLogError(transactionCtx, w, schemas.SubscriptionSelfFollow, http.StatusNotAcceptable,
			errors.New("user cannot subscribe to himself"))
		return
	}

	// Check and throw error if the user is already subscribed to the user he wants to subscribe to
	queryString = "SELECT subscription_id FROM alpha_schema.subscriptions WHERE subscriber_id = $1 AND subscribee_id = $2"
	rows := tx.QueryRow(transactionCtx, queryString, jwtUserId, subscribeeId)
	var subscriptionId uuid.UUID

	if err := rows.Scan(&subscriptionId); err != nil {
		if !errors.Is(err, pgx.ErrNoRows) {
			utils.WriteAndLogError(transactionCtx, w, schemas.DatabaseError, http.StatusInternalServerError, err)
			return
		}
	}

	if subscriptionId != uuid.Nil {
		// User is already subscribed, since the subscriptionId is not nil
		utils.WriteAndLogError(transactionCtx, w, schemas.SubscriptionAlreadyExists, http.StatusConflict,
			errors.New("subscription already exists"))
		return
	}

	// Subscribe the user
	queryString = "INSERT INTO alpha_schema.subscriptions (subscription_id, subscriber_id, subscribee_id, created_at) VALUES ($1, $2, $3, $4)"
	subscriptionId = uuid.New()
	createdAt := time.Now()
	if _, err := tx.Exec(transactionCtx, queryString, subscriptionId, jwtUserId, subscribeeId, createdAt); err != nil {
		log.Errorf("error while inserting subscription: %v", err)
		utils.WriteAndLogError(transactionCtx, w, schemas.DatabaseError, http.StatusInternalServerError, err)
		return
	}

	// Send the subscription to the user
	subscriptionDto := &schemas.SubscriptionDTO{
		SubscriptionId:   subscriptionId,
		SubscriptionDate: createdAt.Format(time.RFC3339),
		Following:        subscriptionRequest.Following,
		Follower:         jwtUsername,
	}

	// Commit the transaction
	if err := utils.CommitTransaction(w, tx, transactionCtx, cancel); err != nil {
		return
	}

	// Send success response
	utils.WriteAndLogResponse(transactionCtx, w, subscriptionDto, http.StatusCreated)
}

// Unsubscribe handles removing a subscription between the current user and the user specified by the subscription ID in the URL.
// It validates the user's authorization to delete the subscription and removes the subscription if authorized.
func (handler *SubscriptionHandler) Unsubscribe(w http.ResponseWriter, r *http.Request) {
	// Begin a new transaction
	tx, transactionCtx, cancel := utils.BeginTransaction(w, r, handler.DatabaseManager.GetPool())
	if tx == nil || transactionCtx == nil {
		return
	}
	var err error
	defer utils.RollbackTransaction(w, tx, transactionCtx, cancel, err)

	// Get the user ID from the JWT token
	claims := r.Context().Value(utils.ClaimsKey).(jwt.MapClaims)
	jwtUserId := claims["sub"].(string)

	// Get subscriptionId from path
	subscriptionId := chi.URLParam(r, utils.SubscriptionIdKey)

	// Get the subscribeeId and subscriberId from the subscriptionId
	queryString := "SELECT subscriber_id, subscribee_id FROM alpha_schema.subscriptions WHERE subscription_id = $1"
	row := tx.QueryRow(transactionCtx, queryString, subscriptionId)
	var subscriberId, subscribeeId string
	if err := row.Scan(&subscriberId, &subscribeeId); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			utils.WriteAndLogError(transactionCtx, w, schemas.SubscriptionNotFound, http.StatusNotFound,
				errors.New("subscription not found"))
			return
		}
		utils.WriteAndLogError(transactionCtx, w, schemas.DatabaseError, http.StatusInternalServerError, err)
		return
	}

	// Check and throw error if user wants to delete someone else's subscription
	if subscriberId != jwtUserId {
		utils.WriteAndLogError(transactionCtx, w, schemas.UnsubscribeForbidden, http.StatusForbidden,
			errors.New("you can only delete your own subscriptions"))
		return
	}

	// Unsubscribe the user
	queryString = "DELETE FROM alpha_schema.subscriptions WHERE subscription_id = $1"
	if _, err := tx.Exec(transactionCtx, queryString, subscriptionId); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			utils.WriteAndLogError(transactionCtx, w, schemas.SubscriptionNotFound, http.StatusNotFound,
				errors.New("subscription not found"))
			return
		}
		utils.WriteAndLogError(transactionCtx, w, schemas.DatabaseError, http.StatusInternalServerError, err)
		return
	}

	// Commit the transaction
	if err := utils.CommitTransaction(w, tx, transactionCtx, cancel); err != nil {
		return
	}

	w.WriteHeader(http.StatusNoContent)
}
